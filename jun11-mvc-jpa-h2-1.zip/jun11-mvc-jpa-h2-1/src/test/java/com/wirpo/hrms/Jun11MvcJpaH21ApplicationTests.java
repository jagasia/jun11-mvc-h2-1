package com.wirpo.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jun11MvcJpaH21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
