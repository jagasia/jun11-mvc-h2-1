package com.wirpo.hrms.exceptions;

public class CustomerAlreadyExist extends Exception {
	public CustomerAlreadyExist(String message)
	{
		super(message);
	}
}
