package com.wirpo.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jun11MvcJpaH21Application {

	public static void main(String[] args) {
		SpringApplication.run(Jun11MvcJpaH21Application.class, args);
	}

}
